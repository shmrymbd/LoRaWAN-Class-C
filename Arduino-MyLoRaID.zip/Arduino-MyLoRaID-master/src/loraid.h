#ifndef _LORAID_H_
#define _LORAID_H_

#include "arduino-rfm/loraid-arduino-rfm.h"

extern LoRaIdClass lora;

#endif
